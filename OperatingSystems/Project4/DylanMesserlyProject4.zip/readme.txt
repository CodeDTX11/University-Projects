Dylan Messerly
Project 4, Operating Systems

To compile program use command:

g++ -std=c++11 compare.cpp


Program will prompt user for number of frames and then will display the results. The reference string is auto generated and is random each execution.
