//Dylan Messerly
Project 3

Part A name: "woLock.c" corresponds to threads with out mutex locks. May have to run progam couple of times to see the interruptions based on the scheduler.
To compile: gcc -pthread -o woLock woLock.c

Part B name: "wLock.c" corresponds to threads with mutex lock. Results always successful.
To compile: gcc -pthread -o wLock wLock.c
