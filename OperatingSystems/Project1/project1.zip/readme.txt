Author: Dylan Messerly
7.13.21

"pre input": <first_name_only(no spaces)> <space> <gpa(float)> <enter> .... <ctrl-d (when finished)>

"sort input": <first_name_only(no spaces)> <enter> .... <ctrl-d (when finished)>

"pipe input": execute program with <./pipe> then follow "pre input" above.

"cmdline input": execute progrm with <./cmdline "option1" "option2" etc>

key: 
< > : means to enter via keyboard
